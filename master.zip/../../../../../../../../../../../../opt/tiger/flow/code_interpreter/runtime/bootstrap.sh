#! /usr/bin/env bash
export PSM=${PSM:-flow.code_interpreter.runtime}
CURDIR=$(cd $(dirname $0); pwd)

if [ "X$1" != "X" ]; then
    RUNTIME_ROOT=$1
else
    RUNTIME_ROOT=${CURDIR}
fi

export KITEX_RUNTIME_ROOT=$RUNTIME_ROOT
export KITEX_CONF_DIR="$CURDIR/conf"
export KITEX_LOG_DIR="${RUNTIME_LOGDIR:-${RUNTIME_ROOT}/log}"

if [ ! -d "$KITEX_LOG_DIR/app" ]; then
    mkdir -p "$KITEX_LOG_DIR/app"
fi

if [ ! -d "$KITEX_LOG_DIR/rpc" ]; then
    mkdir -p "$KITEX_LOG_DIR/rpc"
fi

echo "Astart $(date)" > /bin/runme.log
echo "Astart $(date)" > /mnt/data/runme.log

sh stop_bwrap.sh
sh add_python.sh
sh squid_init.sh
sh start_bwrap.sh
sh file_clear.sh

exec "$CURDIR/bin/flow.code_interpreter.runtime"

echo "Xstart $(date)" >> /bin/runme.log
echo "Xstart $(date)" >> /mnt/data/runme.log
